import argparse
import sys
from PIL import Image
import numpy as np
from scipy.fftpack import dct, idct

BLOCK_SIZE = 8

def str_to_bits(s: str) -> np.ndarray:
    data = s.encode('utf-8')
    return np.unpackbits(np.frombuffer(data, dtype=np.uint8))

def bits_to_str(bits: np.ndarray) -> str:
    n = len(bits) // 8 * 8
    data = np.packbits(bits[:n])
    return data.tobytes().decode('utf-8', errors='ignore')

def embed_bits_in_block(block, bits, idx):
    # Apply DCT
    dct_block = dct(dct(block.T, norm='ortho').T, norm='ortho')
    # Choose a mid-frequency coefficient position
    x, y = 4, 3
    if idx < len(bits):
        coeff = dct_block[x, y]
        # Set LSB of the rounded coefficient
        val = int(np.round(coeff))
        val = (val & ~1) | int(bits[idx])
        # Update coefficient while preserving fractional remainder
        dct_block[x, y] = coeff + (val - np.round(coeff))
        idx += 1
    # Inverse DCT
    block_idct = idct(idct(dct_block.T, norm='ortho').T, norm='ortho')
    return block_idct, idx

def hide(in_path, out_path, message):
    if len(message) > 160:
        print("Error: Message exceeds 160 characters.", file=sys.stderr)
        sys.exit(1)

    bits = str_to_bits(message)
    img = Image.open(in_path).convert('L')  # use grayscale
    arr = np.array(img, dtype=float)
    h, w = arr.shape
    # Pad to multiple of BLOCK_SIZE
    h_pad = (BLOCK_SIZE - h % BLOCK_SIZE) % BLOCK_SIZE
    w_pad = (BLOCK_SIZE - w % BLOCK_SIZE) % BLOCK_SIZE
    arr = np.pad(arr, ((0, h_pad), (0, w_pad)), mode='constant')
    nblocks_h = arr.shape[0] // BLOCK_SIZE
    nblocks_w = arr.shape[1] // BLOCK_SIZE

    idx = 0
    for i in range(nblocks_h):
        for j in range(nblocks_w):
            y0, y1 = i*BLOCK_SIZE, (i+1)*BLOCK_SIZE
            x0, x1 = j*BLOCK_SIZE, (j+1)*BLOCK_SIZE
            block = arr[y0:y1, x0:x1]
            block_mod, idx = embed_bits_in_block(block, bits, idx)
            arr[y0:y1, x0:x1] = block_mod
            if idx >= bits.size:
                break
        if idx >= bits.size:
            break

    # Clip and convert back to uint8
    arr = np.clip(arr, 0, 255).astype(np.uint8)
    stego = Image.fromarray(arr, mode='L')
    stego.save(out_path, 'JPEG')
    print(f"Message hidden in '{{}}' successfully.".format(out_path))

def extract(in_path):
    img = Image.open(in_path).convert('L')
    arr = np.array(img, dtype=float)
    h, w = arr.shape
    nblocks_h = h // BLOCK_SIZE
    nblocks_w = w // BLOCK_SIZE

    bits = []
    for i in range(nblocks_h):
        for j in range(nblocks_w):
            y0, y1 = i*BLOCK_SIZE, (i+1)*BLOCK_SIZE
            x0, x1 = j*BLOCK_SIZE, (j+1)*BLOCK_SIZE
            block = arr[y0:y1, x0:x1]
            dct_block = dct(dct(block.T, norm='ortho').T, norm='ortho')
            x, y = 4, 3
            val = int(np.round(dct_block[x, y]))
            bits.append(val & 1)
            if len(bits) >= 160*8:
                break
        if len(bits) >= 160*8:
            break

    message = bits_to_str(np.array(bits, dtype=np.uint8))
    print("Extracted message:")
    print(message)

if __name__ == '__main__':
    p = argparse.ArgumentParser(description="JPEG-DCT steganography")
    sub = p.add_subparsers(dest='cmd', required=True)
    hide_p = sub.add_parser('hide')
    hide_p.add_argument('--in', dest='in_file', required=True, help="Input JPEG image")
    hide_p.add_argument('--out', dest='out_file', required=True, help="Output stego JPEG image")
    hide_p.add_argument('--msg', dest='message', required=True, help="Message (<=160 chars)")

    ext_p = sub.add_parser('extract')
    ext_p.add_argument('--in', dest='in_file', required=True, help="Stego JPEG image")

    args = p.parse_args()
    if args.cmd == 'hide':
        hide(args.in_file, args.out_file, args.message)
    elif args.cmd == 'extract':
        extract(args.in_file)
