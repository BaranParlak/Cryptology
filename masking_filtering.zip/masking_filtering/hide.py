import argparse
import sys
import cv2
import numpy as np

def str_to_bits(s: str) -> np.ndarray:
    data = s.encode('utf-8')
    return np.unpackbits(np.frombuffer(data, dtype=np.uint8))

def bits_to_str(bits: np.ndarray) -> str:
    n = len(bits) // 8 * 8
    data = np.packbits(bits[:n])
    return data.tobytes().decode('utf-8', errors='ignore')

def hide(in_file, out_file, message):
    if len(message) > 160:
        print("Error: Message exceeds 160 characters.", file=sys.stderr)
        sys.exit(1)

    # Read image in grayscale
    img = cv2.imread(in_file, cv2.IMREAD_GRAYSCALE)
    if img is None:
        print(f"Error: Cannot read image '{in_file}'", file=sys.stderr)
        sys.exit(1)
    h, w = img.shape

    bits = str_to_bits(message)
    total_bits = bits.size
    # FFT
    f = np.fft.fft2(img.astype(float))
    fshift = np.fft.fftshift(f)
    # Embed bits into magnitude LSB in low-frequency mask region
    mag = np.abs(fshift)
    phase = np.angle(fshift)

    # choose center block size
    c_h, c_w = h//4, w//4
    start_h, start_w = h//2 - c_h//2, w//2 - c_w//2
    region = mag[start_h:start_h+c_h, start_w:start_w+c_w].flatten()

    if total_bits > region.size:
        print("Error: Image too small for message.", file=sys.stderr)
        sys.exit(1)

    # embed in LSB of rounded magnitude
    region_int = np.round(region).astype(np.int64)
    region_int[:total_bits] = (region_int[:total_bits] & ~1) | bits
    # adjust magnitude to include fractional part
    frac = region - np.floor(region)
    region_mod = region_int + frac

    # put back
    mag_flat = mag.flatten()
    mag_flat[start_h*w + start_w : start_h*w + start_w + region_mod.size] = region_mod
    mag_mod = mag_flat.reshape(h, w)

    # reconstruct FFT
    fshift_mod = mag_mod * np.exp(1j*phase)
    f_ishift = np.fft.ifftshift(fshift_mod)
    img_back = np.fft.ifft2(f_ishift)
    img_back = np.real(img_back)
    img_back = np.clip(img_back, 0, 255).astype(np.uint8)

    cv2.imwrite(out_file, img_back)
    print(f"Message hidden in '{out_file}' successfully.")

def extract(in_file):
    img = cv2.imread(in_file, cv2.IMREAD_GRAYSCALE)
    if img is None:
        print(f"Error: Cannot read image '{in_file}'", file=sys.stderr)
        sys.exit(1)
    h, w = img.shape
    # FFT
    f = np.fft.fft2(img.astype(float))
    fshift = np.fft.fftshift(f)
    mag = np.abs(fshift)

    c_h, c_w = h//4, w//4
    start_h, start_w = h//2 - c_h//2, w//2 - c_w//2
    region = mag[start_h:start_h+c_h, start_w:start_w+c_w].flatten()

    bits = (np.round(region).astype(np.int64) & 1)[:160*8]
    message = bits_to_str(bits.astype(np.uint8))
    print("Extracted message:")
    print(message)

if __name__ == '__main__':
    p = argparse.ArgumentParser(description="Masking & Filtering steganography (image-based)")
    sub = p.add_subparsers(dest='cmd', required=True)
    hide_p = sub.add_parser('hide')
    hide_p.add_argument('--in', dest='in_file', required=True, help="Input image file")
    hide_p.add_argument('--out', dest='out_file', required=True, help="Output stego image")
    hide_p.add_argument('--msg', dest='message', required=True, help="Message (<=160 chars)")
    ext_p = sub.add_parser('extract')
    ext_p.add_argument('--in', dest='in_file', required=True, help="Stego image file")
    args = p.parse_args()
    if args.cmd == 'hide':
        hide(args.in_file, args.out_file, args.message)
    elif args.cmd == 'extract':
        extract(args.in_file)
