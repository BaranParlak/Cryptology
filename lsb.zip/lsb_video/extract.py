import cv2
import numpy as np
import argparse

def bits_to_str(bits: np.ndarray) -> str:
    n = len(bits) // 8 * 8
    data = np.packbits(bits[:n])
    return data.tobytes().decode('utf-8', errors='ignore')

def extract(in_file: str):
    cap = cv2.VideoCapture(in_file)
    bits = []
    num_bits = 160 * 8

    while len(bits) < num_bits:
        ret, frame = cap.read()
        if not ret:
            break
        flat = frame.flatten()
        for b in flat:
            if len(bits) >= num_bits:
                break
            bits.append(int(b & 1))

    cap.release()
    msg = bits_to_str(np.array(bits, dtype=np.uint8))
    print("Extracted message:")
    print(msg)

if __name__ == '__main__':
    p = argparse.ArgumentParser(description="LSB video steganography - extract")
    p.add_argument('--in', dest='in_file', required=True, help="Stego video file")
    args = p.parse_args()
    extract(args.in_file)
