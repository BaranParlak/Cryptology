import cv2
import numpy as np
import argparse
import sys

def str_to_bits(s: str) -> np.ndarray:
    data = s.encode('utf-8')
    return np.unpackbits(np.frombuffer(data, dtype=np.uint8))

def hide(in_file: str, out_file: str, message: str):
    if len(message) > 160:
        print("Error: Message cannot exceed 160 characters.", file=sys.stderr)
        sys.exit(1)

    cap = cv2.VideoCapture(in_file)
    if not cap.isOpened():
        print("Error: Cannot open video file.", file=sys.stderr)
        sys.exit(1)

    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    fps    = cap.get(cv2.CAP_PROP_FPS)
    w      = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h      = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    out    = cv2.VideoWriter(out_file, fourcc, fps, (w, h))

    bits = str_to_bits(message)
    total_bits = bits.size
    idx = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        flat = frame.flatten()
        for i in range(flat.size):
            if idx >= total_bits:
                break
            flat[i] = (flat[i] & ~1) | int(bits[idx])
            idx += 1

        frame_mod = flat.reshape(frame.shape)
        out.write(frame_mod)
        if idx >= total_bits:
            while True:
                ret2, frm2 = cap.read()
                if not ret2:
                    break
                out.write(frm2)
            break

    cap.release()
    out.release()
    print(f"Message hidden in '{out_file}' successfully.")

if __name__ == '__main__':
    p = argparse.ArgumentParser(description="LSB video steganography - hide")
    p.add_argument('--in', dest='in_file', required=True, help="Input video file")
    p.add_argument('--out', dest='out_file', required=True, help="Output video (stego) file")
    p.add_argument('--msg', dest='message', required=True, help="Message (<=160 chars)")
    args = p.parse_args()
    hide(args.in_file, args.out_file, args.message)
