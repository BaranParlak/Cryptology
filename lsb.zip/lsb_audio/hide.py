import wave
import numpy as np
import argparse
import sys

def str_to_bits(s: str) -> np.ndarray:
    data = s.encode('utf-8')
    bits = np.unpackbits(np.frombuffer(data, dtype=np.uint8))
    return bits

def hide(in_file: str, out_file: str, message: str):
    if len(message) > 160:
        print("Error: Message cannot exceed 160 characters.", file=sys.stderr)
        sys.exit(1)

    wav = wave.open(in_file, mode='rb')
    params = wav.getparams()
    frames = wav.readframes(params.nframes)
    wav.close()

    samples = np.frombuffer(frames, dtype=np.int16)
    bits = str_to_bits(message)
    total_bits = bits.size
    if total_bits > samples.size:
        print("Error: Audio file too small to hide message.", file=sys.stderr)
        sys.exit(1)

    samples_mod = samples.copy()
    samples_mod[:total_bits] &= ~1
    samples_mod[:total_bits] |= bits

    out_wav = wave.open(out_file, mode='wb')
    out_wav.setparams(params)
    out_wav.writeframes(samples_mod.tobytes())
    out_wav.close()
    print(f"Message hidden in '{out_file}' successfully.")

if __name__ == '__main__':
    p = argparse.ArgumentParser(description="LSB audio steganography - hide")
    p.add_argument('--in', dest='in_file', required=True, help="Input WAV file")
    p.add_argument('--out', dest='out_file', required=True, help="Output WAV (stego) file")
    p.add_argument('--msg', dest='message', required=True, help="Message (<=160 chars)")
    args = p.parse_args()
    hide(args.in_file, args.out_file, args.message)
