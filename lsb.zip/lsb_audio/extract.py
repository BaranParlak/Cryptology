import wave
import numpy as np
import argparse

def bits_to_str(bits: np.ndarray) -> str:
    n = len(bits) // 8 * 8
    data = np.packbits(bits[:n])
    return data.tobytes().decode('utf-8', errors='ignore')

def extract(in_file: str):
    wav = wave.open(in_file, mode='rb')
    frames = wav.readframes(wav.getnframes())
    wav.close()
    samples = np.frombuffer(frames, dtype=np.int16)

    num_bits = 160 * 8
    bits = samples[:num_bits] & 1
    msg = bits_to_str(bits)
    print("Extracted message:")
    print(msg)

if __name__ == '__main__':
    p = argparse.ArgumentParser(description="LSB audio steganography - extract")
    p.add_argument('--in', dest='in_file', required=True, help="Stego WAV file")
    args = p.parse_args()
    extract(args.in_file)
