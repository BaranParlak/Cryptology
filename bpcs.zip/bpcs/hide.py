import argparse
import sys
from PIL import Image
import numpy as np

def str_to_bits(s: str) -> np.ndarray:
    data = s.encode('utf-8')
    return np.unpackbits(np.frombuffer(data, dtype=np.uint8))

def bits_to_str(bits: np.ndarray) -> str:
    n = len(bits) // 8 * 8
    data = np.packbits(bits[:n])
    return data.tobytes().decode('utf-8', errors='ignore')

def embed_message(img_arr: np.ndarray, bits: np.ndarray) -> np.ndarray:
    # Split into bit-planes
    h, w = img_arr.shape
    planes = np.unpackbits(img_arr.reshape(-1,1), axis=1).reshape(h, w, 8)
    # Flatten selected bit-planes (4..7) for embedding
    flat_planes = np.concatenate([planes[:,:,7].flatten(), planes[:,:,6].flatten(),
                                  planes[:,:,5].flatten(), planes[:,:,4].flatten()])
    if bits.size > flat_planes.size:
        print("Error: Message too long for image capacity.", file=sys.stderr)
        sys.exit(1)
    # Embed bits
    flat_planes[:bits.size] = bits
    # Put back into planes
    idx = 0
    for b in [7,6,5,4]:
        size = h*w
        planes[:,:,b] = flat_planes[idx:idx+size].reshape(h, w)
        idx += size
    # Reconstruct image
    recon = np.packbits(planes.reshape(-1,8), axis=1).reshape(h, w)
    return recon

def hide(in_path, out_path, message):
    if len(message) > 160:
        print("Error: Message exceeds 160 characters.", file=sys.stderr)
        sys.exit(1)
    bits = str_to_bits(message)
    img = Image.open(in_path).convert('L')
    arr = np.array(img, dtype=np.uint8)
    stego_arr = embed_message(arr, bits)
    stego = Image.fromarray(stego_arr, mode='L')
    stego.save(out_path)
    print(f"Message hidden in '{out_path}' successfully.")

def extract(in_path):
    img = Image.open(in_path).convert('L')
    arr = np.array(img, dtype=np.uint8)
    h, w = arr.shape
    planes = np.unpackbits(arr.reshape(-1,1), axis=1).reshape(h, w, 8)
    # Flatten same planes
    flat_planes = np.concatenate([planes[:,:,7].flatten(), planes[:,:,6].flatten(),
                                  planes[:,:,5].flatten(), planes[:,:,4].flatten()])
    bits = flat_planes[:160*8].astype(np.uint8)
    message = bits_to_str(bits)
    print("Extracted message:")
    print(message)

if __name__ == '__main__':
    p = argparse.ArgumentParser(description="BPCS steganography (simple bit-plane embedding)")
    sub = p.add_subparsers(dest='cmd', required=True)
    hide_p = sub.add_parser('hide')
    hide_p.add_argument('--in', dest='in_file', required=True, help="Input grayscale image (PNG/JPG)")
    hide_p.add_argument('--out', dest='out_file', required=True, help="Output stego image")
    hide_p.add_argument('--msg', dest='message', required=True, help="Message (<=160 chars)")
    ext_p = sub.add_parser('extract')
    ext_p.add_argument('--in', dest='in_file', required=True, help="Stego image")
    args = p.parse_args()
    if args.cmd == 'hide':
        hide(args.in_file, args.out_file, args.message)
    elif args.cmd == 'extract':
        extract(args.in_file)
