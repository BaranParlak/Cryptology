import argparse
import sys
import numpy as np
import cv2

def chi_square_test(image, bit_plane=0):
    # Perform Chi-square analysis on LSB plane
    flat = image.flatten()
    bits = flat & 1
    # Count zeros and ones
    zeros = np.sum(bits == 0)
    ones = np.sum(bits == 1)
    total = zeros + ones
    # Expected equal distribution
    expected = total / 2
    chi_sq = ((zeros - expected)**2 + (ones - expected)**2) / expected
    return chi_sq

def detect(in_file):
    img = cv2.imread(in_file, cv2.IMREAD_GRAYSCALE)
    if img is None:
        print(f"Error: Cannot read '{in_file}'", file=sys.stderr)
        sys.exit(1)
    chi = chi_square_test(img)
    print(f"Chi-square statistic for LSB plane: {chi:.2f}")
    if chi < 3.841:  # 0.05 significance threshold
        print("Likely contains hidden data (reject H0).")
    else:
        print("Likely does not contain hidden data (cannot reject H0).")

if __name__ == '__main__':
    p = argparse.ArgumentParser(description="Heuristic steganalysis - detect hidden data")
    p.add_argument('--in', dest='in_file', required=True, help="Input image file")
    args = p.parse_args()
    detect(args.in_file)
