import argparse
import sys
import numpy as np
import cv2

def extract_lsb(in_file, num_bits=160*8):
    img = cv2.imread(in_file, cv2.IMREAD_GRAYSCALE)
    flat = img.flatten()
    bits = flat[:num_bits] & 1
    data = np.packbits(bits)
    try:
        return data.tobytes().decode('utf-8')
    except UnicodeDecodeError:
        return data.tobytes().decode('latin-1', errors='ignore')

def extract(in_file):
    message = extract_lsb(in_file)
    print("Extracted LSB message attempt:")
    print(message)

if __name__ == '__main__':
    p = argparse.ArgumentParser(description="Heuristic steganalysis - extract from LSB plane")
    p.add_argument('--in', dest='in_file', required=True, help="Input image file")
    args = p.parse_args()
    extract(args.in_file)
